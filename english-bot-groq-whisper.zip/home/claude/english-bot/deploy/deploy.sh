#!/bin/bash
set -e

echo "🚀 Начинаем деплой English Bot..."

# ─── 1. Системные зависимости ────────────────────────────────
echo "📦 Устанавливаем системные зависимости..."
apt-get update -qq
apt-get install -y python3.11 python3.11-venv python3.11-dev \
    build-essential ffmpeg git curl htop 2>/dev/null || true

# Если python3.11 не нашёлся — добавляем репозиторий
if ! command -v python3.11 &>/dev/null; then
    add-apt-repository ppa:deadsnakes/ppa -y
    apt-get update -qq
    apt-get install -y python3.11 python3.11-venv python3.11-dev
fi

echo "✅ Python версия: $(python3.11 --version)"

# ─── 2. Создаём пользователя ─────────────────────────────────
echo "👤 Создаём пользователя botuser..."
if ! id "botuser" &>/dev/null; then
    useradd -m -s /bin/bash botuser
fi

# ─── 3. Копируем проект ──────────────────────────────────────
echo "📁 Копируем файлы проекта..."
cp -r /root/english-bot /home/botuser/english-bot 2>/dev/null || true
chown -R botuser:botuser /home/botuser/english-bot
mkdir -p /home/botuser/english-bot/data
chown botuser:botuser /home/botuser/english-bot/data

# ─── 4. Виртуальное окружение ────────────────────────────────
echo "🐍 Создаём виртуальное окружение на Python 3.11..."
rm -rf /home/botuser/english-bot/.venv
sudo -u botuser python3.11 -m venv /home/botuser/english-bot/.venv

echo "📥 Устанавливаем зависимости..."
sudo -u botuser /home/botuser/english-bot/.venv/bin/pip install --upgrade pip -q
sudo -u botuser /home/botuser/english-bot/.venv/bin/pip install -r /home/botuser/english-bot/requirements.txt

# ─── 5. Проверяем .env ───────────────────────────────────────
if [ ! -f /home/botuser/english-bot/.env ]; then
    if [ -f /root/english-bot/.env ]; then
        cp /root/english-bot/.env /home/botuser/english-bot/.env
        chown botuser:botuser /home/botuser/english-bot/.env
        echo "✅ .env скопирован"
    else
        echo "❌ Файл .env не найден в /root/english-bot/.env"
        exit 1
    fi
fi

# ─── 6. Systemd сервисы ──────────────────────────────────────
echo "⚙️  Настраиваем systemd сервисы..."
cp /home/botuser/english-bot/deploy/english-bot-api.service /etc/systemd/system/
cp /home/botuser/english-bot/deploy/english-bot.service /etc/systemd/system/

systemctl daemon-reload
systemctl enable english-bot-api english-bot
systemctl restart english-bot-api

echo "⏳ Ждём запуска бэкенда (10 сек)..."
sleep 10

if curl -s http://localhost:8000/health | grep -q "ok"; then
    echo "✅ Бэкенд запущен"
    systemctl restart english-bot
    echo "✅ Бот запущен"
else
    echo "❌ Бэкенд не ответил — смотри логи:"
    journalctl -u english-bot-api -n 30
    exit 1
fi

echo ""
echo "🎉 Деплой завершён!"
echo ""
echo "Полезные команды:"
echo "  Логи бэкенда:  journalctl -u english-bot-api -f"
echo "  Логи бота:     journalctl -u english-bot -f"
echo "  Перезапуск:    systemctl restart english-bot-api && systemctl restart english-bot"
echo "  Статус:        systemctl status english-bot-api english-bot"
