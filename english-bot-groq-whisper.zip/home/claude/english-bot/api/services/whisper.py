import tempfile
import asyncio
from pathlib import Path
from groq import AsyncGroq
from config.settings import settings

client = AsyncGroq(api_key=settings.GROQ_API_KEY)


async def transcribe(audio_bytes: bytes, filename: str = "audio.ogg") -> str:
    """Транскрибирует аудио через Groq Whisper API."""
    if not audio_bytes:
        raise ValueError("Пустой аудио файл")

    suffix = Path(filename).suffix or ".ogg"

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name

    try:
        with open(tmp_path, "rb") as f:
            result = await client.audio.transcriptions.create(
                file=(Path(tmp_path).name, f),
                model="whisper-large-v3",
                language="en",
                response_format="text",
            )
        text = result.strip() if isinstance(result, str) else result.text.strip()
        if not text:
            raise RuntimeError("Не удалось распознать речь — попробуй ещё раз")
        return text
    except asyncio.TimeoutError:
        raise RuntimeError("Транскрипция заняла слишком долго")
    finally:
        Path(tmp_path).unlink(missing_ok=True)
